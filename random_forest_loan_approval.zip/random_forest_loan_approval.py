# 預測貸款是否通過 random forest
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
import joblib
from sklearn.metrics import classification_report
import numpy as np

loan_df=pd.read_csv('D:/Joy/python/loan_approval_dataset.csv')
loan_df.head()
print(loan_df.columns)


loan_df.dropna(inplace=True)

# 計算loan_status 列中每個唯一值的出現次數
loan_status_counts = loan_df[' loan_status'].value_counts()

# 計算貸款狀態
plt.figure(figsize=(6, 4))
plt.bar(loan_status_counts.index, loan_status_counts.values, color=['lightgreen', 'mediumpurple'])
plt.title('Loan Status Distribution')
plt.xlabel('Loan Status')
plt.ylabel('Count')
plt.show()


education_counts = loan_df[' education'].value_counts()

plt.figure(figsize=(6, 6))
plt.pie(education_counts, labels=education_counts.index, autopct='%1.1f%%', colors=['mistyrose', 'yellow'])
plt.title('Education Distribution')
plt.show()

loan_df.columns = loan_df.columns.str.strip()

if 'education' in loan_df.columns and 'loan_status' in loan_df.columns:

    education_loan_status_counts = loan_df.groupby(['education', 'loan_status']).size().unstack()

    plt.figure(figsize=(8, 6))
    education_loan_status_counts.plot(kind='bar', stacked=True)
    plt.title('Loan Status by Education Level')
    plt.xlabel('Education Level')
    plt.ylabel('Count')
    plt.legend(title='Loan Status', loc='upper right', labels=['Approved', 'Rejected'])
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.show()
sns.histplot(data=loan_df,x='cibil_score',bins=4,hue='loan_status')
plt.title('cibil score')
plt.show()
sns.countplot(x = 'no_of_dependents', data = loan_df, hue = 'loan_status')

sns.countplot(x='self_employed', data = loan_df, hue = 'education').set_title('Self Employed')

label_encoder = LabelEncoder()
loan_df['education_numeric'] = label_encoder.fit_transform(loan_df['education'])
loan_df['self_employed_numeric'] = label_encoder.fit_transform(loan_df['self_employed'])
loan_df['self_employed'] = loan_df['self_employed_numeric']
loan_df['education'] = loan_df['education_numeric']
loan_df.drop('education_numeric', axis=1, inplace=True)
loan_df.drop('self_employed_numeric', axis=1, inplace=True)
loan_df.head()
print(loan_df.columns)

features = [
    'no_of_dependents', 'education', 'self_employed',
       'income_annum', 'loan_amount', 'loan_term', 'cibil_score',
       'residential_assets_value', 'commercial_assets_value',
       'luxury_assets_value', 'bank_asset_value'
]

target = 'loan_status'
X = loan_df[features]
y = loan_df[target]
X.shape

# rf=RandomForestClassifier(**rf_Grid.best_params_)
# rf.fit(X_train,y_train)

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)
# 創建隨機森林分類器模型
model = RandomForestClassifier(n_estimators=10, random_state=42)
# 訓練模型
model.fit(X_train, y_train)

# y_pred1=rf.predict(X_test)
# 使用測試集進行預測
y_pred = model.predict(X_test)

# 第五步：評估模型
print("混淆矩陣:")
print(confusion_matrix(y_test, y_pred))

print("\n分類報告:")
print(classification_report(y_test, y_pred))


# 計算並顯示分類報告
report = classification_report(y_test, y_pred)
print(report)

# 印出預測結果
predictions = pd.DataFrame({'Predicted Loan Status': y_pred})
predictions['Can Pass Loan'] = predictions['Predicted Loan Status'].map({1: 'Yes', 0: 'No'})

print("\n預測結果:")
print(predictions)

# 計算並顯示分類報告
report = classification_report(y_test, y_pred)
print(report)

'''
precision：正確預測的正例數量與所有預測為正例的數量之比。
recall：正確預測的正例數量與所有實際正例的數量之比。
f1-score：精確率和召回率的調和平均數，提供一個綜合的性能指標。
support：每個類別的實際樣本數量。
'''
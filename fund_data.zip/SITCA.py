# 1222 done
import pandas as pd

# 讀取 Excel 文件
file_path = 'D://Joy//python//境內基金.xlsx' 
df = pd.read_excel(file_path)
print(df.columns)
# print(df['代號'])
df = df[~df['類型'].str.contains("投信", na=False)]

# 檢查讀取的數據
print("原始數據:")
print(df.head())
# df = df[~df['代號'].str.contains("投信", na=False)]
# 第一步：合併列標題與第一行和第二行的數據
new_column_data = []
for col in df.columns:
    # 獲取列標題、第一行和第二行的數據
    header = col
    row0 = df[col].iloc[0] if len(df[col]) > 0 else ''
    row1 = df[col].iloc[1] if len(df[col]) > 1 else ''
    
    # 將 NaN 和空白替換為空字符串
    row0 = '' if pd.isna(row0) or str(row0).strip() == '' else row0
    row1 = '' if pd.isna(row1) or str(row1).strip() == '' else row1
    # 合併成一個字符串
    merged_value = f"{header} {row0} {row1}".strip()  # 去除多餘的空格
    new_column_data.append(merged_value)


# 將合併的結果作為新的列添加到 DataFrame 中
# print(df.loc[6836])
df.columns = new_column_data
print(df.columns)
print(df.head(13))
df = df[2:].reset_index(drop=True) 
print(df.head(13))

# 第一步：處理基金統編和基金名稱
rows_to_delete = []  # 用於存儲需要刪除的行索引

for i in range(len(df) - 1):  # 遍歷到倒數第二行
    # 檢查當前行的基金統編是否有值，且下一行的基金統編為空
    if pd.notna(df.at[i, '基金統編']) and pd.isna(df.at[i + 1, '基金統編']):
        # 合併基金名稱
        df.at[i, '基金名稱'] = f"{df.at[i, '基金名稱']} {df.at[i + 1, '基金名稱']}".strip()
        rows_to_delete.append(i + 1)  # 記錄下一行的索引以便刪除
print(rows_to_delete)
print(df.head(15))

# 刪除需要刪除的行
df = df.drop(index=rows_to_delete).reset_index(drop=True)
print(df.head(10))

output_file = 'processed_fund_data.xlsx'
df.to_excel(output_file, index=False)
# 印出結果
# print("處理後的數據:")
# print(df)


# 將結果寫入新的 Excel 文件
output_file = 'processed_fund_data.xlsx'
df.to_excel(output_file, index=False)